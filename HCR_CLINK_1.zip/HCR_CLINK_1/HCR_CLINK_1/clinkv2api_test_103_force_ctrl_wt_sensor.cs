﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace clinkv2api_test_cs
{
    public partial class clinkv2api_TestMain
    {
        public int runTest()
        {
            Console.WriteLine("===== (103) Force Control =====");

            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            //---------------------------------------------------------------------
            // servo on
            //---------------------------------------------------------------------
            Console.WriteLine("+++++++++ servo on +++++++++");

            // clinkCs.robot_servo_switch_set은 actuator의 servo를 On/Off하는 함수
            // CLINK_SWITCH_ON : servo on
            // CLINK_SWITCH_OFF : servo off
            caRetVal = clinkCs.robot_servo_switch_set(robotID, CLINK_SWITCH.CLINK_SWITCH_ON);
            Thread.Sleep(200);

            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_servo_switch_set(ON) ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            //---------------------------------------------------------------------
            //  각 축 homing
            //---------------------------------------------------------------------
            Console.WriteLine("+++++++++ robot homing +++++++++");

            // 로봇을 설정된 초기 위치로 복귀
            caRetVal = move_homing(robotID); 
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: move_homing() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }



            //----------------------------------------------------------------------
            //-Object Search mode-
            //----------------------------------------------------------------------

            // collision detection off
            // clinkCs.robot_collision_detection_switch_set은 collision detection 사용 유무를 설정하는 함수
            // CLINK_SWITCH_ON : collision detection on
            // CLINK_SWITCH_OFF : collision detection off
            // 본 예제에서는 기능을 OFF한다.
            caRetVal = clinkCs.robot_collision_detection_switch_set(robotID, CLINK_SWITCH.CLINK_SWITCH_OFF);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_collision_detection_switch_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // clinkCs.robot_collision_detection_switch_get를 활용하여
            // 위의 설정의 유효함을 확인 한다.
            //디버깅 완료 후 불필요.
            int a;
            caRetVal = clinkCs.robot_collision_detection_switch_get(robotID, out a);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((a != (int)CLINK_SWITCH.CLINK_SWITCH_OFF))
                {
                    Console.WriteLine(" **** Error: collision detection on...");
                }
                else
                    Console.WriteLine(" **** Error does not exist: collision detection off...");
            }
            else
            {
                Console.WriteLine("Error: collision detection off... ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }



            // set force torque sensor
            //clinkCs.robot_force_torq_sensor_switch_set은  force sensor를 사용하도록 설정하는 함수
            // CLINK_SWITCH_ON : force sensor on
            // CLINK_SWITCH_OFF : force sensor off
            // 본 예제에서는 기능을 OFF 한다.
            caRetVal = clinkCs.robot_force_torq_sensor_switch_set(robotID, CLINK_SWITCH.CLINK_SWITCH_ON);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_torq_sensor_switch_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }


            // clinkCs.robot_force_torq_sensor_switch_get를 활용하여
            // 위의 설정의 유효함을 확인 한다.
            // 디버깅 완료 후 불필요.
            int b;
            caRetVal = clinkCs.robot_force_torq_sensor_switch_get(robotID, out b);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((b != (int)CLINK_SWITCH.CLINK_SWITCH_ON))
                {
                    Console.WriteLine(" **** Error: sensor disable...");
                }
                else
                    Console.WriteLine(" **** Error does not exist: sensor enable...");
            }
            else
            {
                Console.WriteLine("Error: sensor disable... ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }


            // set tcp coordinate
            //clinkCs.robot_force_ctrl_coordination_set은 기본좌표계를 TCP좌표계로 변환시켜 주는 함수
            // CLINK_REF_COORDINATE_TCP : TCP coordinate 사용
            // CLINK_REF_COORDINATE_BASE : BASE coordinate 사용
            // 본 예제에서는 TCP기능을 사용한다.
            // 이 함수를 사용하지 않을경우, 모든 좌표계는 Base좌표계를 기본으로 설정
            caRetVal = clinkCs.robot_force_ctrl_coordination_set(robotID, CLINK_REF_COORDINATE.CLINK_REF_COORDINATE_TCP);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_TCP_coordination_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // clinkCs.robot_force_ctrl_coordination_get를 활용하여
            // 위의 설정의 유효함을 확인 한다.
            // 디버깅 완료 후 불필요.
            int c;
            caRetVal = clinkCs.robot_force_ctrl_coordination_get(robotID, out c);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((c != (int)CLINK_REF_COORDINATE.CLINK_REF_COORDINATE_TCP))
                {
                    Console.WriteLine(" **** Error: BASE_coordinate...");
                }
                else
                    Console.WriteLine(" **** Error does not exist: TCP_coordinate...");
            }
            else
            {
                Console.WriteLine("Error: TCP_coordinate... ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }


            // force control direction setting
            //clinkCs.robot_force_ctrl_direction_switch_set은 각 축별 force control 사용 유무 설정를 설정하는 함수
            //CLINK_SWITCH_ON: 사용
            //CLINK_SWITCH_OFF: 미사용
            //본 예제에서는 force control의 Z-axis방향만 enable한다.
            //왼쪽부터 x, y, z, rx, ry, rz순서로 사용 유무 설정
            caRetVal = clinkCs.robot_force_ctrl_direction_switch_set(robotID,
                            CLINK_SWITCH.CLINK_SWITCH_OFF, CLINK_SWITCH.CLINK_SWITCH_OFF, CLINK_SWITCH.CLINK_SWITCH_ON,
                            CLINK_SWITCH.CLINK_SWITCH_OFF, CLINK_SWITCH.CLINK_SWITCH_OFF, CLINK_SWITCH.CLINK_SWITCH_OFF);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_force_ctrl_direction_switch_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            Thread.Sleep(1000);
            // clinkCs.robot_force_ctrl_direction_switch_get를 활용하여
            // 위의 설정의 유효함을 확인 한다.
            // 디버깅 완료 후 불필요.
            int sw_x, sw_y, sw_z, sw_rx, sw_ry, sw_rz;
            caRetVal = clinkCs.robot_force_ctrl_direction_switch_get(robotID, out sw_x, out sw_y, out sw_z, out sw_rx, out sw_ry, out sw_rz);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((sw_x != (int)CLINK_SWITCH.CLINK_SWITCH_OFF) || (sw_y != (int)CLINK_SWITCH.CLINK_SWITCH_OFF) || (sw_z != (int)CLINK_SWITCH.CLINK_SWITCH_ON)
                    || (sw_rx != (int)CLINK_SWITCH.CLINK_SWITCH_OFF) || (sw_ry != (int)CLINK_SWITCH.CLINK_SWITCH_OFF) || (sw_rz != (int)CLINK_SWITCH.CLINK_SWITCH_OFF)
                    )
                {
                    Console.WriteLine(" **** Error: [force control] direction switch off state...");
                }
                else
                    Console.WriteLine(" **** Error does not exist: [force control] direction switch on state...");

            }
            else
            {
                Console.WriteLine("Error: robot_force_ctrl_direction_switch_get() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // force control: end effector force setting
            // clinkCs.robot_force_ctrl_force_set는 desired force값을 입력으로 설정하는 함수
            // x, y, z, tx, ty, tz 순서로 크기와 방향 설정
            // 본 예제에서는 Z-axis방향으로 30N을 설정한다.
            // +/-극성 설정에 따라 방향 설정 변경가능
            caRetVal = clinkCs.robot_force_ctrl_force_set(robotID, 0.0F, 0.0F, 0.5F, 0.0F, 0.0F, 0.0F);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_force_ctrl_force_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // clinkCs.robot_force_ctrl_force_get를 활용하여
            // 위의 설정의 유효함을 확인 한다.
            // 디버깅 완료 후 불필요.
            float fx, fy, fz, tx, ty, tz;
            caRetVal = clinkCs.robot_force_ctrl_force_get(robotID, out fx, out fy, out fz, out tx, out ty, out tz);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((fx > 0.0001F) || (fx < -0.0001F) || (fy > 0.0001F) || (fy< -0.0001F) || (fz > 10.0001F) || (fz < 9.9999F)
                    || (tx > 0.0001F) || (fx < -0.0001F) || (ty > 0.0001F) || (ty < -0.0001F) || (tz > 0.0001F) || (tz < -0.0001F)
                    )
                { 
                    Console.WriteLine(" **** Error: [force control] end effector force value...");
                }
                else
                    Console.WriteLine(" **** Error does not exist: [force control] end effector force value...");
            }
            else
            {
                Console.WriteLine("Error: robot_force_ctrl_force_get() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // force control: end effector velocity setting
            // clinkCs.robot_force_ctrl_velocity_set는 force control시에 사용되는 최대 velocity 설정하는 함수
            // 본 예제에서는 Z-axis 방향으로 50mm/s를 설정한다.
            caRetVal = clinkCs.robot_force_ctrl_velocity_set(robotID, 0.0F, 0.0F, 20.0F, 0.0F, 0.0F, 0.0F);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_force_ctrl_velocity_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // clinkCs.robot_force_ctrl_velocity_get를 활용하여
            // 위의 설정의 유효함을 확인 한다.
            // 디버깅 완료 후 불필요.
            float vx, vy, vz, rx, ry, rz;
            caRetVal = clinkCs.robot_force_ctrl_velocity_get(robotID, out vx, out vy, out vz, out rx, out ry, out rz);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((vx > 0.0001F) || (vx < -0.0001F) || (vy > 0.0001F) || (vy < -0.0001F) || (vz > 20.0001F) || (vz < 19.9999F)
                    || (rx > 0.0001F) || (rx < -0.0001F) || (ry > 0.0001F) || (ry < -0.0001F) || (rz > 0.0001F) || (rz < -0.0001F)
                    )
                {
                    Console.WriteLine(" **** Error: [force control] end effector velocity value...");
                }
                else
                    Console.WriteLine(" **** Error does not exist: [force control] end effector velocity value...");
            }
            else
            {
                Console.WriteLine("Error: robot_force_ctrl_velocity_get() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }


            // force control: end effector acceleration setting
            // clinkCs.robot_force_ctrl_acc_set는 force control시에 사용되는 acceleration을 설정하는 함수.
            // ax, ay, az, r_ax, r_ay, r_az 순서로 설정 
            // 본 예제에서는 Z-axis 방향으로 500mm/s^2을 설정한다.
            caRetVal = clinkCs.robot_force_ctrl_acc_set(robotID, 0.0F, 0.0F, 1000.0F, 0.0F, 0.0F, 0.0F);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_force_ctrl_acceleration_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // clinkCs.robot_force_ctrl_acc_get를 활용하여
            // 위의 설정의 유효함을 확인 한다.
            // 디버깅 완료 후 불필요.
            caRetVal = clinkCs.robot_force_ctrl_acc_get(robotID, out vx, out vy, out vz, out rx, out ry, out rz);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((vx > 0.0001F) || (vx < -0.0001F) || (vy > 0.0001F) || (vy < -0.0001F) || (vz > 1000.0001F) || (vz < 999.9999F)
                    || (rx > 0.0001F) || (rx < -0.0001F) || (ry > 0.0001F) || (ry < -0.0001F) || (rz > 0.0001F) || (rz < -0.0001F)
                    )
                {
                    Console.WriteLine(" **** Error: [force control] end effector acceleration value...");
                }
                else
                    Console.WriteLine(" **** Error does not exist: [force control] end effector acceleration value...");
            }
            else
            {
                Console.WriteLine("Error: robot_force_ctrl_acceleration_get() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // force control: end effector deceleration setting
            //clinkCs.robot_force_ctrl_dec_set는 force control시에 사용되는 deceleration을 설정하는 함수.
            //dx, dy, dz, r_dx, r_dy, r_dz 순서로 설정 
            //본 예제에서는 Z-axis 방향으로 500mm/s^2을 설정한다.
            caRetVal = clinkCs.robot_force_ctrl_dec_set(robotID, 0.0F, 0.0F, 1000.0F, 0.0F, 0.0F, 0.0F);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_force_ctrl_deceleration_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // clinkCs.robot_force_ctrl_dec_get를 활용하여
            // 위의 설정의 유효함을 확인 한다.
            // 디버깅 완료 후 불필요.
            caRetVal = clinkCs.robot_force_ctrl_dec_get(robotID, out vx, out vy, out vz, out rx, out ry, out rz);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((vx > 0.0001F) || (vx < -0.0001F) || (vy > 0.0001F) || (vy < -0.0001F) || (vz > 1000.0001F) || (vz < 999.9999F)
                    || (rx > 0.0001F) || (rx < -0.0001F) || (ry > 0.0001F) || (ry < -0.0001F) || (rz > 0.0001F) || (rz < -0.0001F)
                    )
                {
                    Console.WriteLine(" **** Error: [force control] end effector deceleration value...");
                }
                else
                    Console.WriteLine(" **** Error does not exist: [force control] end effector deceleration value...");
            }
            else
            {
                Console.WriteLine("Error: robot_force_ctrl_deceleration_get() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // force control: end effector damping setting
            // clinkCs.robot_force_ctrl_dampling_ratio_set은 force control의 damping ratio를 설정하는 함수
            // x, y, z에 해당하는 damping ratio값과 rx, ry, rz에 해당하는 damping ratio값 두 개 설정
            // 본 예제에서는 damping ratio를 7로 설정한다.
            caRetVal = clinkCs.robot_force_ctrl_damping_ratio_set(robotID, 5.0F, 15.0F);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_force_ctrl_damping_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // clinkCs.robot_force_ctrl_damping_ratio_get를 활용하여
            // 위의 설정의 유효함을 확인 한다.
            // 디버깅 완료 후 불필요.
            caRetVal = clinkCs.robot_force_ctrl_damping_ratio_get(robotID, out vx, out vy);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((vx > 5.0001F) || (vx < 4.9999F) || (vy > 15.0001F) || (vy < 14.9999F))
                {
                    Console.WriteLine(" **** Error: [force control] end effector damping value...");
                }
                else
                    Console.WriteLine(" **** Error does not exist: [force control] end effector damping value...");
            }
            else
            {
                Console.WriteLine("Error: robot_force_ctrl_damping_get() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // force control: end effector stiffness setting
            // clinkCs.robot_force_ctrl_stiffness_set은 force control의 stiffness 설정하는 함수
            // x, y, z, rx, ry, rz축에 해당하는 stiffness값을 차례로 설정.
            // 본 예제에서는 stiffness값을 Z-axis방향으로 200N/m로 설정한다.
            caRetVal = clinkCs.robot_force_ctrl_stiffness_set(robotID, 0.0F, 0.0F, 1000.0F, 0.0F, 0.0F, 0.0F);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_force_ctrl_stiffness_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // clinkCs.robot_force_ctrl_stiffness_get를 활용하여
            // 위의 설정의 유효함을 확인 한다.
            // 디버깅 완료 후 불필요.
            caRetVal = clinkCs.robot_force_ctrl_stiffness_get(robotID, out vx, out vy, out vz, out rx, out ry, out rz);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((vx > 0.0001F) || (vx < -0.0001F) || (vy > 0.0001F) || (vy < -0.0001F) || (vz > 1000.0001F) || (vz < 999.9999F)
                    || (rx > 0.0001F) || (rx < -0.0001F) || (ry > 0.0001F) || (ry < -0.0001F) || (rz > 0.0001F) || (rz < -0.0001F)
                    )
                {
                    Console.WriteLine(" **** Error: [force control] end effector stiffness value...");
                }
                else
                    Console.WriteLine(" **** Error does not exist: [force control] end effector stiffness value...");

            }
            else
            {
                Console.WriteLine("Error: robot_force_ctrl_stiffness_get() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }



            // force command startservo
            // force command의 동작이 가능한지 판단하기 위해 키보드로부터 입력받음
            // 키보드 입력(enter key)이 한번 있으면 force command 알고리즘이 동작
            // clinkCs.robot_force_ctrl_switch_set은 force control 알고리즘을 enable/disable하는 함수
            // CLINK_SWITCH_ON: force control 알고리즘 enable
            // CLINK_SWITCH_OFF: force control 알고리즘 disable
            // 본 예제에서는 force control 알고리즘 기능을 enable 한다.
            Console.WriteLine("If you start force command test, please push enter key");
            string pushedKey = Console.ReadLine();

            caRetVal = clinkCs.robot_force_ctrl_switch_set(robotID, CLINK_SWITCH.CLINK_SWITCH_ON);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_force_ctrl_switch_set(ON) ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // clinkCs.robot_force_ctrl_switch_get를 활용하여
            // 위의 설정의 유효함을 확인 한다.
            // 디버깅 완료 후 불필요.
            int sw_fc;
            caRetVal = clinkCs.robot_force_ctrl_switch_get(robotID, out sw_fc);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if (sw_fc != (int)CLINK_SWITCH.CLINK_SWITCH_ON)
                {
                    Console.WriteLine(" **** Error: [force control] force control mode is not {0} but {1}...", CLINK_SWITCH.CLINK_SWITCH_ON, sw_fc);
                }
                else
                    Console.WriteLine(" **** Error does not exist: [force control] force control mode is not {0} but {1}...", CLINK_SWITCH.CLINK_SWITCH_ON, sw_fc);
            }
            else
            {
                Console.WriteLine("Error: robot_force_ctrl_switch_get() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }


            //----------------------------------------------------------------------
            //
            //----------------------------------------------------------------------




            //----------------------------------------------------------------------
            //-Contact detection-
            //----------------------------------------------------------------------

            bool ObjectDetecting =false;
            while (false == ObjectDetecting)
            {
                //Monitoring of actual force 
                float forceX, forceY, forceZ;
                caRetVal = clinkCs.robot_force_ctrl_actual_force_get(robotID, out forceX, out forceY, out forceZ);

                //if set value of contact force is 10N, it is recommended to set the contact force to 8N
                //about 80 percent of contact force
                if (forceZ > 8)
                {
                    ObjectDetecting = true;
                    Console.WriteLine("+++++++++++  Object is detected  +++++++++++");
                }
                else
                {
                    Console.WriteLine("+++++++++++  searching for object  +++++++++++");
                }
            }
            //----------------------------------------------------------------------
            //
            //----------------------------------------------------------------------




            //----------------------------------------------------------------------
            //-Initialization of contact force-
            //----------------------------------------------------------------------
            // set force torque sensor off
            caRetVal = clinkCs.robot_force_torq_sensor_switch_set(robotID, CLINK_SWITCH.CLINK_SWITCH_ON);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_torq_sensor_switch_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }


            // clinkCs.robot_force_torq_sensor_switch_get를 활용하여
            // 위의 설정의 유효함을 확인 한다.
            // 디버깅 완료 후 불필요.
            //int b;
            caRetVal = clinkCs.robot_force_torq_sensor_switch_get(robotID, out b);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((b != (int)CLINK_SWITCH.CLINK_SWITCH_ON))
                {
                    Console.WriteLine(" **** Error: sensor disable...");
                }
                else
                    Console.WriteLine(" **** Error does not exist: sensor enable...");
            }
            else
            {
                Console.WriteLine("Error: sensor disable... ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }


            // set tcp coordinate
            //clinkCs.robot_force_ctrl_coordination_set은 기본좌표계를 TCP좌표계로 변환시켜 주는 함수
            // CLINK_REF_COORDINATE_TCP : TCP coordinate 사용
            // CLINK_REF_COORDINATE_BASE : BASE coordinate 사용
            // 본 예제에서는 TCP기능을 사용한다.
            // 이 함수를 사용하지 않을경우, 모든 좌표계는 Base좌표계를 기본으로 설정
            caRetVal = clinkCs.robot_force_ctrl_coordination_set(robotID, CLINK_REF_COORDINATE.CLINK_REF_COORDINATE_TCP);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_TCP_coordination_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // clinkCs.robot_force_ctrl_coordination_get를 활용하여
            // 위의 설정의 유효함을 확인 한다.
            // 디버깅 완료 후 불필요.
            caRetVal = clinkCs.robot_force_ctrl_coordination_get(robotID, out c);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((c != (int)CLINK_REF_COORDINATE.CLINK_REF_COORDINATE_TCP))
                {
                    Console.WriteLine(" **** Error: BASE_coordinate...");
                }
                else
                    Console.WriteLine(" **** Error does not exist: TCP_coordinate...");
            }
            else
            {
                Console.WriteLine("Error: TCP_coordinate... ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }


            // force control direction setting
            //clinkCs.robot_force_ctrl_direction_switch_set은 각 축별 force control 사용 유무 설정를 설정하는 함수
            //CLINK_SWITCH_ON: 사용
            //CLINK_SWITCH_OFF: 미사용
            //본 예제에서는 force control의 Z-axis방향만 enable한다.
            //왼쪽부터 x, y, z, rx, ry, rz순서로 사용 유무 설정
            caRetVal = clinkCs.robot_force_ctrl_direction_switch_set(robotID,
                            CLINK_SWITCH.CLINK_SWITCH_OFF, CLINK_SWITCH.CLINK_SWITCH_OFF, CLINK_SWITCH.CLINK_SWITCH_ON,
                            CLINK_SWITCH.CLINK_SWITCH_OFF, CLINK_SWITCH.CLINK_SWITCH_OFF, CLINK_SWITCH.CLINK_SWITCH_OFF);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_force_ctrl_direction_switch_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            Thread.Sleep(1000);
            // clinkCs.robot_force_ctrl_direction_switch_get를 활용하여
            // 위의 설정의 유효함을 확인 한다.
            // 디버깅 완료 후 불필요.
         //   int sw_x, sw_y, sw_z, sw_rx, sw_ry, sw_rz;
            caRetVal = clinkCs.robot_force_ctrl_direction_switch_get(robotID, out sw_x, out sw_y, out sw_z, out sw_rx, out sw_ry, out sw_rz);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((sw_x != (int)CLINK_SWITCH.CLINK_SWITCH_OFF) || (sw_y != (int)CLINK_SWITCH.CLINK_SWITCH_OFF) || (sw_z != (int)CLINK_SWITCH.CLINK_SWITCH_ON)
                    || (sw_rx != (int)CLINK_SWITCH.CLINK_SWITCH_OFF) || (sw_ry != (int)CLINK_SWITCH.CLINK_SWITCH_OFF) || (sw_rz != (int)CLINK_SWITCH.CLINK_SWITCH_OFF)
                    )
                {
                    Console.WriteLine(" **** Error: [force control] direction switch off state...");
                }
                else
                    Console.WriteLine(" **** Error does not exist: [force control] direction switch on state...");

            }
            else
            {
                Console.WriteLine("Error: robot_force_ctrl_direction_switch_get() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // force control: end effector force setting
            // clinkCs.robot_force_ctrl_force_set는 desired force값을 입력으로 설정하는 함수
            // x, y, z, tx, ty, tz 순서로 크기와 방향 설정
            // 본 예제에서는 Z-axis방향으로 30N을 설정한다.
            // +/-극성 설정에 따라 방향 설정 변경가능
            caRetVal = clinkCs.robot_force_ctrl_force_set(robotID, 0.0F, 0.0F, 5.0F, 0.0F, 0.0F, 0.0F);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_force_ctrl_force_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // clinkCs.robot_force_ctrl_force_get를 활용하여
            // 위의 설정의 유효함을 확인 한다.
            // 디버깅 완료 후 불필요.
        //    float fx, fy, fz, tx, ty, tz;
            caRetVal = clinkCs.robot_force_ctrl_force_get(robotID, out fx, out fy, out fz, out tx, out ty, out tz);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((fx > 0.0001F) || (fx < -0.0001F) || (fy > 0.0001F) || (fy < -0.0001F) || (fz > 10.0001F) || (fz < 9.9999F)
                    || (tx > 0.0001F) || (fx < -0.0001F) || (ty > 0.0001F) || (ty < -0.0001F) || (tz > 0.0001F) || (tz < -0.0001F)
                    )
                {
                    Console.WriteLine(" **** Error: [force control] end effector force value...");
                }
                else
                    Console.WriteLine(" **** Error does not exist: [force control] end effector force value...");
            }
            else
            {
                Console.WriteLine("Error: robot_force_ctrl_force_get() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // force control: end effector velocity setting
            // clinkCs.robot_force_ctrl_velocity_set는 force control시에 사용되는 최대 velocity 설정하는 함수
            // 본 예제에서는 Z-axis 방향으로 50mm/s를 설정한다.
            caRetVal = clinkCs.robot_force_ctrl_velocity_set(robotID, 0.0F, 0.0F, 2.0F, 0.0F, 0.0F, 0.0F);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_force_ctrl_velocity_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // clinkCs.robot_force_ctrl_velocity_get를 활용하여
            // 위의 설정의 유효함을 확인 한다.
            // 디버깅 완료 후 불필요.
       //     float vx, vy, vz, rx, ry, rz;
            caRetVal = clinkCs.robot_force_ctrl_velocity_get(robotID, out vx, out vy, out vz, out rx, out ry, out rz);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((vx > 0.0001F) || (vx < -0.0001F) || (vy > 0.0001F) || (vy < -0.0001F) || (vz > 2.0001F) || (vz < 1.9999F)
                    || (rx > 0.0001F) || (rx < -0.0001F) || (ry > 0.0001F) || (ry < -0.0001F) || (rz > 0.0001F) || (rz < -0.0001F)
                    )
                {
                    Console.WriteLine(" **** Error: [force control] end effector velocity value...");
                }
                else
                    Console.WriteLine(" **** Error does not exist: [force control] end effector velocity value...");
            }
            else
            {
                Console.WriteLine("Error: robot_force_ctrl_velocity_get() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }


            // force control: end effector acceleration setting
            // clinkCs.robot_force_ctrl_acc_set는 force control시에 사용되는 acceleration을 설정하는 함수.
            // ax, ay, az, r_ax, r_ay, r_az 순서로 설정 
            // 본 예제에서는 Z-axis 방향으로 500mm/s^2을 설정한다.
            caRetVal = clinkCs.robot_force_ctrl_acc_set(robotID, 0.0F, 0.0F, 1000.0F, 0.0F, 0.0F, 0.0F);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_force_ctrl_acceleration_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // clinkCs.robot_force_ctrl_acc_get를 활용하여
            // 위의 설정의 유효함을 확인 한다.
            // 디버깅 완료 후 불필요.
            caRetVal = clinkCs.robot_force_ctrl_acc_get(robotID, out vx, out vy, out vz, out rx, out ry, out rz);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((vx > 0.0001F) || (vx < -0.0001F) || (vy > 0.0001F) || (vy < -0.0001F) || (vz > 1000.0001F) || (vz < 999.9999F)
                    || (rx > 0.0001F) || (rx < -0.0001F) || (ry > 0.0001F) || (ry < -0.0001F) || (rz > 0.0001F) || (rz < -0.0001F)
                    )
                {
                    Console.WriteLine(" **** Error: [force control] end effector acceleration value...");
                }
                else
                    Console.WriteLine(" **** Error does not exist: [force control] end effector acceleration value...");
            }
            else
            {
                Console.WriteLine("Error: robot_force_ctrl_acceleration_get() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // force control: end effector deceleration setting
            //clinkCs.robot_force_ctrl_dec_set는 force control시에 사용되는 deceleration을 설정하는 함수.
            //dx, dy, dz, r_dx, r_dy, r_dz 순서로 설정 
            //본 예제에서는 Z-axis 방향으로 500mm/s^2을 설정한다.
            caRetVal = clinkCs.robot_force_ctrl_dec_set(robotID, 0.0F, 0.0F, 1000.0F, 0.0F, 0.0F, 0.0F);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_force_ctrl_deceleration_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // clinkCs.robot_force_ctrl_dec_get를 활용하여
            // 위의 설정의 유효함을 확인 한다.
            // 디버깅 완료 후 불필요.
            caRetVal = clinkCs.robot_force_ctrl_dec_get(robotID, out vx, out vy, out vz, out rx, out ry, out rz);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((vx > 0.0001F) || (vx < -0.0001F) || (vy > 0.0001F) || (vy < -0.0001F) || (vz > 1000.0001F) || (vz < 999.9999F)
                    || (rx > 0.0001F) || (rx < -0.0001F) || (ry > 0.0001F) || (ry < -0.0001F) || (rz > 0.0001F) || (rz < -0.0001F)
                    )
                {
                    Console.WriteLine(" **** Error: [force control] end effector deceleration value...");
                }
                else
                    Console.WriteLine(" **** Error does not exist: [force control] end effector deceleration value...");
            }
            else
            {
                Console.WriteLine("Error: robot_force_ctrl_deceleration_get() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // force control: end effector damping setting
            // clinkCs.robot_force_ctrl_dampling_ratio_set은 force control의 damping ratio를 설정하는 함수
            // x, y, z에 해당하는 damping ratio값과 rx, ry, rz에 해당하는 damping ratio값 두 개 설정
            // 본 예제에서는 damping ratio를 7로 설정한다.
            caRetVal = clinkCs.robot_force_ctrl_damping_ratio_set(robotID, 5.0F, 15.0F);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_force_ctrl_damping_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // clinkCs.robot_force_ctrl_damping_ratio_get를 활용하여
            // 위의 설정의 유효함을 확인 한다.
            // 디버깅 완료 후 불필요.
            caRetVal = clinkCs.robot_force_ctrl_damping_ratio_get(robotID, out vx, out vy);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((vx > 5.0001F) || (vx < 4.9999F) || (vy > 15.0001F) || (vy < 14.9999F))
                {
                    Console.WriteLine(" **** Error: [force control] end effector damping value...");
                }
                else
                    Console.WriteLine(" **** Error does not exist: [force control] end effector damping value...");
            }
            else
            {
                Console.WriteLine("Error: robot_force_ctrl_damping_get() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // force control: end effector stiffness setting
            // clinkCs.robot_force_ctrl_stiffness_set은 force control의 stiffness 설정하는 함수
            // x, y, z, rx, ry, rz축에 해당하는 stiffness값을 차례로 설정.
            // 본 예제에서는 stiffness값을 Z-axis방향으로 200N/m로 설정한다.
            caRetVal = clinkCs.robot_force_ctrl_stiffness_set(robotID, 0.0F, 0.0F, 1000.0F, 0.0F, 0.0F, 0.0F);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_force_ctrl_stiffness_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // clinkCs.robot_force_ctrl_stiffness_get를 활용하여
            // 위의 설정의 유효함을 확인 한다.
            // 디버깅 완료 후 불필요.
            caRetVal = clinkCs.robot_force_ctrl_stiffness_get(robotID, out vx, out vy, out vz, out rx, out ry, out rz);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((vx > 0.0001F) || (vx < -0.0001F) || (vy > 0.0001F) || (vy < -0.0001F) || (vz > 1000.0001F) || (vz < 999.9999F)
                    || (rx > 0.0001F) || (rx < -0.0001F) || (ry > 0.0001F) || (ry < -0.0001F) || (rz > 0.0001F) || (rz < -0.0001F)
                    )
                {
                    Console.WriteLine(" **** Error: [force control] end effector stiffness value...");
                }
                else
                    Console.WriteLine(" **** Error does not exist: [force control] end effector stiffness value...");

            }
            else
            {
                Console.WriteLine("Error: robot_force_ctrl_stiffness_get() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }



            // force command startservo
            // force command의 동작이 가능한지 판단하기 위해 키보드로부터 입력받음
            // 키보드 입력(enter key)이 한번 있으면 force command 알고리즘이 동작
            // clinkCs.robot_force_ctrl_switch_set은 force control 알고리즘을 enable/disable하는 함수
            // CLINK_SWITCH_ON: force control 알고리즘 enable
            // CLINK_SWITCH_OFF: force control 알고리즘 disable
            // 본 예제에서는 force control 알고리즘 기능을 enable 한다.

            caRetVal = clinkCs.robot_force_ctrl_switch_set(robotID, CLINK_SWITCH.CLINK_SWITCH_ON);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_force_ctrl_switch_set(ON) ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // clinkCs.robot_force_ctrl_switch_get를 활용하여
            // 위의 설정의 유효함을 확인 한다.
            // 디버깅 완료 후 불필요.
           // int sw_fc;
            caRetVal = clinkCs.robot_force_ctrl_switch_get(robotID, out sw_fc);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if (sw_fc != (int)CLINK_SWITCH.CLINK_SWITCH_ON)
                {
                    Console.WriteLine(" **** Error: [force control] force control mode is not {0} but {1}...", CLINK_SWITCH.CLINK_SWITCH_ON, sw_fc);
                }
                else
                    Console.WriteLine(" **** Error does not exist: [force control] force control mode is not {0} but {1}...", CLINK_SWITCH.CLINK_SWITCH_ON, sw_fc);
            }
            else
            {
                Console.WriteLine("Error: robot_force_ctrl_switch_get() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }


            //Force Control disable
            caRetVal = clinkCs.robot_force_ctrl_switch_set(robotID, CLINK_SWITCH.CLINK_SWITCH_OFF);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_force_ctrl_switch_set(ON) ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }
            Console.WriteLine("+++++++++ Force control disable +++++++++");

            Thread.Sleep(3000);

            //----------------------------------------------------------------------
            //-
            //----------------------------------------------------------------------




            //----------------------------------------------------------------------
            //-Default force control-
            //----------------------------------------------------------------------

            // collision detection off
            caRetVal = clinkCs.robot_collision_detection_switch_set(robotID, CLINK_SWITCH.CLINK_SWITCH_OFF);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_collision_detection_switch_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // set force torque sensor, sensor mode
            caRetVal = clinkCs.robot_force_torq_sensor_switch_set(robotID, CLINK_SWITCH.CLINK_SWITCH_ON);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_torq_sensor_switch_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // set tcp coordinate
            caRetVal = clinkCs.robot_force_ctrl_coordination_set(robotID, CLINK_REF_COORDINATE.CLINK_REF_COORDINATE_TCP);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_TCP_coordination_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // force control direction setting
            caRetVal = clinkCs.robot_force_ctrl_direction_switch_set(robotID,
                            CLINK_SWITCH.CLINK_SWITCH_OFF, CLINK_SWITCH.CLINK_SWITCH_OFF, CLINK_SWITCH.CLINK_SWITCH_ON,
                            CLINK_SWITCH.CLINK_SWITCH_OFF, CLINK_SWITCH.CLINK_SWITCH_OFF, CLINK_SWITCH.CLINK_SWITCH_OFF);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_force_ctrl_direction_switch_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }
   
            // force control: end effector force setting
            caRetVal = clinkCs.robot_force_ctrl_force_set(robotID, 0.0F, 0.0F, 5.0F, 0.0F, 0.0F, 0.0F);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_force_ctrl_force_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // force control: end effector velocity setting
            caRetVal = clinkCs.robot_force_ctrl_velocity_set(robotID, 0.0F, 0.0F, 50.0F, 0.0F, 0.0F, 0.0F);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_force_ctrl_velocity_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // force control: end effector acceleration setting
            caRetVal = clinkCs.robot_force_ctrl_acc_set(robotID, 0.0F, 0.0F, 1000.0F, 0.0F, 0.0F, 0.0F);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_force_ctrl_acceleration_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // force control: end effector deceleration setting
            caRetVal = clinkCs.robot_force_ctrl_dec_set(robotID, 0.0F, 0.0F, 1000.0F, 0.0F, 0.0F, 0.0F);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_force_ctrl_deceleration_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            //damping ratio set
            caRetVal = clinkCs.robot_force_ctrl_damping_ratio_set(robotID, 5.0F, 15.0F);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_force_ctrl_damping_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // force control: end effector stiffness setting
            caRetVal = clinkCs.robot_force_ctrl_stiffness_set(robotID, 0.0F, 0.0F, 1000.0F, 0.0F, 0.0F, 0.0F);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_force_ctrl_stiffness_set() ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            //Force control enable
            caRetVal = clinkCs.robot_force_ctrl_switch_set(robotID, CLINK_SWITCH.CLINK_SWITCH_ON);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_force_ctrl_switch_set(ON) ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }
            //----------------------------------------------------------------------
            //
            //----------------------------------------------------------------------





            //----------------------------------------------------------------------
            // Linear motion, parameters setting
            //----------------------------------------------------------------------

            Console.WriteLine("===== (01) move liner =====");

            caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            const int NUM_OF_ITERATION = 20;
            const float ROBOT_MOVE_VELOCITY = 50.0F;

            //---------------------------------------------------------------------
            // Safety limit 설정
            //---------------------------------------------------------------------
            Console.WriteLine("+++++++++ Safety limit setting +++++++++");
            caRetVal = clinkCs.robot_safety_limit_tcp_speed_max_set(robotID, ROBOT_MOVE_VELOCITY);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_safety_limit_tcp_speed_max_set() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            float val;
            caRetVal = clinkCs.robot_safety_limit_tcp_speed_max_get(robotID, out val);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if (val != ROBOT_MOVE_VELOCITY)
                {
                    Console.WriteLine(" **** Error: TCP Speed max is not [{0}] but [{1}]", ROBOT_MOVE_VELOCITY, val);
                }
            }
            else
            {
                Console.WriteLine("Error: robot_safety_limit_tcp_speed_max_get() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            
            
            // 현재 로봇의 위치값 확인
            float pos_x, pos_y, pos_z, ort_x, ort_y, ort_z;
            caRetVal = clinkCs.robot_tcp_pose_actual_get(robotID, out pos_x, out pos_y, out pos_z, out ort_x, out ort_y, out ort_z);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("---- info: (acutual) Position=({0}, {1}, {2}), Orientation=({3}, {4}, {5})", pos_x, pos_y, pos_z, ort_x, ort_y, ort_z);
            }
            else
            {
                Console.WriteLine("Error: robot_tcp_pose_actual_get() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }


            // 테스트를 위한 4각형의 꼭지점에 해당하는 포인트.
            // 운용 SW 에서 way point에 해당.

            float[,] RECT_POINT = new float[4, 3];
            RECT_POINT[0, 0] = pos_x;
            RECT_POINT[0, 1] = pos_y;
            RECT_POINT[0, 2] = pos_z;

            RECT_POINT[1, 0] = pos_x + 100.0F;
            RECT_POINT[1, 1] = pos_y;
            RECT_POINT[1, 2] = pos_z;

            RECT_POINT[2, 0] = pos_x + 100.0F;
            RECT_POINT[2, 1] = pos_y + 100.0F;
            RECT_POINT[2, 2] = pos_z;

            RECT_POINT[3, 0] = pos_x;
            RECT_POINT[3, 1] = pos_y + 100.0F;
            RECT_POINT[3, 2] = pos_z;


            //---------------------------------------------------------------------
            // create a motion command data (TCP)
            //---------------------------------------------------------------------
            Console.WriteLine("+++++++++ create motion command (TCP) +++++++++");
            uint baseMtCmdID = 0;
            caRetVal = clinkCs.motion_command_robot_tcp_create(out baseMtCmdID);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: motion_command_robot_tcp_create() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            caRetVal = clinkCs.motion_command_robot_robot_id_set(baseMtCmdID, robotID);
            Thread.Sleep(200);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: motion_command_robot_robot_id_set() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            uint curRbID;
            caRetVal = clinkCs.motion_command_robot_robot_id_get(baseMtCmdID, out curRbID);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if (curRbID != robotID)
                {
                    Console.WriteLine(" **** Error: Robot ID is different.");
                }
            }
            else
            {
                Console.WriteLine("Error: motion_command_robot_robot_id_get() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }


            //---------------------------------------------------------------------
            // 이동을 위한 parameter 설정
            //---------------------------------------------------------------------
            Console.WriteLine("+++++++++ set motion parameters for TCP +++++++++");

            // 최대 command velocity 설정
            caRetVal = clinkCs.motion_command_speed_max_set(baseMtCmdID, ROBOT_MOVE_VELOCITY);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: motion_command_speed_max_set() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            Thread.Sleep(80);
            caRetVal = clinkCs.motion_command_speed_max_get(baseMtCmdID, out val);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((val < (ROBOT_MOVE_VELOCITY - 0.01)) || (val > (ROBOT_MOVE_VELOCITY + 0.01)))
                {
                    Console.WriteLine(" **** Error: Speed max (in motion command) is different.");
                }
            }
            else
            {
                Console.WriteLine("Error: motion_command_speed_max_get() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            // 최대 command accelaration 설정
            caRetVal = clinkCs.motion_command_acc_max_set(baseMtCmdID, ROBOT_MOVE_VELOCITY * 10);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: motion_command_acc_max_set() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            Thread.Sleep(80);
            caRetVal = clinkCs.motion_command_acc_max_get(baseMtCmdID, out val);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((val < (ROBOT_MOVE_VELOCITY * 10 - 0.01)) || (val > (ROBOT_MOVE_VELOCITY * 10 + 0.01)))
                {
                    Console.WriteLine(" **** Error: Accelaration max (in motion command) is different.");
                }
            }
            else
            {
                Console.WriteLine("Error: motion_command_acc_max_get() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            // 최대 command decelaration 설정
            caRetVal = clinkCs.motion_command_dec_max_set(baseMtCmdID, ROBOT_MOVE_VELOCITY * 10);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: motion_command_dec_max_set() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            Thread.Sleep(80);
            caRetVal = clinkCs.motion_command_dec_max_get(baseMtCmdID, out val);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((val < (ROBOT_MOVE_VELOCITY * 10 - 0.01)) || (val > (ROBOT_MOVE_VELOCITY * 10 + 0.01)))
                {
                    Console.WriteLine(" **** Error: Decelaration max (in motion command) is different.");
                }
            }
            else
            {
                Console.WriteLine("Error: motion_command_dec_max_get() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            // Jerk percentage 설정
            caRetVal = clinkCs.motion_command_jerk_percentage_set(baseMtCmdID, 1.0F);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: motion_command_jerk_percentage_set() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            Thread.Sleep(80);
            caRetVal = clinkCs.motion_command_jerk_percentage_get(baseMtCmdID, out val);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((val < (1.0F - 0.01F)) || (val > (1.0F + 0.01F)))
                {
                    Console.WriteLine(" **** Error: Jerk percentage (in motion command) is different.");
                }
            }
            else
            {
                Console.WriteLine("Error: motion_command_jerk_percentage_get() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            // TCP coordination type
            // Linear motion은 BASE 좌표계 기준으로 동작함
            caRetVal = clinkCs.motion_command_robot_tcp_coordination_set(baseMtCmdID, CLINK_REF_COORDINATE.CLINK_REF_COORDINATE_BASE);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: motion_command_robot_tcp_coordination_set() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            Thread.Sleep(80);
            int refCoord;
            caRetVal = clinkCs.motion_command_robot_tcp_coordination_get(baseMtCmdID, out refCoord);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if (refCoord != (int)CLINK_REF_COORDINATE.CLINK_REF_COORDINATE_BASE)
                {
                    Console.WriteLine(" **** Error: TCP coordination type (in motion command) is different.");
                }
            }
            else
            {
                Console.WriteLine("Error: motion_command_robot_tcp_coordination_get() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            // TCP interpolator type
            // joint motion이 아닌 task space linear motion
            caRetVal = clinkCs.motion_command_robot_tcp_interpolator_set(baseMtCmdID, CLINK_INTERPOLATOR.CLINK_INTERPOLATOR_LINEAR);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: motion_command_robot_tcp_interpolator_set() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            Thread.Sleep(80);
            int itpl;
            caRetVal = clinkCs.motion_command_robot_tcp_interpolator_get(baseMtCmdID, out itpl);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if (itpl != (int)CLINK_INTERPOLATOR.CLINK_INTERPOLATOR_LINEAR)
                {
                    Console.WriteLine(" **** Error: TCP interpolator type (in motion command) is different.");
                }
            }
            else
            {
                Console.WriteLine("Error: motion_command_robot_tcp_interpolator_get() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            // TCP start orientation
            // Endeffector단에서의 시작orientation 설정
            caRetVal = clinkCs.motion_command_robot_tcp_orientation_start_set(baseMtCmdID, ort_x, ort_y, ort_z);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: motion_command_robot_tcp_orientation_start_set() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            Thread.Sleep(80);
            float tmp_ort_x, tmp_ort_y, tmp_ort_z;
            caRetVal = clinkCs.motion_command_robot_tcp_orientation_start_get(baseMtCmdID, out tmp_ort_x, out tmp_ort_y, out tmp_ort_z);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((tmp_ort_x < (ort_x - 0.01)) || (tmp_ort_x > (ort_x + 0.01)) || (tmp_ort_y < (ort_y - 0.01)) || (tmp_ort_y > (ort_y + 0.01)) || (tmp_ort_z < (ort_z - 0.01)) || (tmp_ort_z > (ort_z + 0.01)))
                {
                    Console.WriteLine(" **** Error: TCP orientation (start) is different.");
                }
            }
            else
            {
                Console.WriteLine("Error: motion_command_robot_tcp_orientation_start_get() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            // TCP end orientation
            // Endeffector단에서의 종료 orientation 설정
            caRetVal = clinkCs.motion_command_robot_tcp_orientation_end_set(baseMtCmdID, ort_x, ort_y, ort_z);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: motion_command_robot_tcp_orientation_end_set() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            Thread.Sleep(80);
            caRetVal = clinkCs.motion_command_robot_tcp_orientation_end_get(baseMtCmdID, out tmp_ort_x, out tmp_ort_y, out tmp_ort_z);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((tmp_ort_x < (ort_x - 0.01)) || (tmp_ort_x > (ort_x + 0.01)) || (tmp_ort_y < (ort_y - 0.01)) || (tmp_ort_y > (ort_y + 0.01)) || (tmp_ort_z < (ort_z - 0.01)) || (tmp_ort_z > (ort_z + 0.01)))
                {
                    Console.WriteLine(" **** Error: TCP orientation (end) is different.");
                }
            }
            else
            {
                Console.WriteLine("Error: motion_command_robot_tcp_orientation_end_get() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }


            //---------------------------------------------------------------------
            //  Linear Move 활용, 사각형 그리기
            //---------------------------------------------------------------------

            bool bIsRunning = true;
            uint curMtCmdID;
            int eventResult;
            float tmp_pos_x, tmp_pos_y, tmp_pos_z;

            for (int iterIndex = 0; iterIndex < NUM_OF_ITERATION; iterIndex++)
            {
                if (bIsRunning)
                {
                    Console.WriteLine("+++++++++ iteration: {0} +++++++++", iterIndex);
                    for (int rectPtIndex = 0; rectPtIndex < 4; rectPtIndex++)
                    {
                        Console.WriteLine("+++++++++ rectPtIndex: {0} +++++++++", rectPtIndex);
                        // create a motion command by deep copying of previous motion command
                        caRetVal = clinkCs.motion_command_deep_copy(baseMtCmdID, out curMtCmdID);
                        if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                        {
                            caRetVal = clinkCs.motion_command_destroy(baseMtCmdID);
                            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                            {
                                baseMtCmdID = curMtCmdID;
                            }
                            else
                            {
                                Console.WriteLine("Error: motion_command_destroy() ({0})", clinkCs.system_api_result_description_get(caRetVal));
                            }
                        }
                        else
                        {
                            Console.WriteLine("Error: motion_command_deep_copy() ({0})", clinkCs.system_api_result_description_get(caRetVal));
                        }

                        // TCP start position test
                        // Endeffector단에서의 시작 위치 설정
                        caRetVal = clinkCs.motion_command_robot_tcp_position_start_set(curMtCmdID, pos_x, pos_y, pos_z);
                        if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                        {
                            Console.WriteLine("Error: motion_command_robot_tcp_position_start_set() ({0})", clinkCs.system_api_result_description_get(caRetVal));
                        }

                        caRetVal = clinkCs.motion_command_robot_tcp_position_start_get(curMtCmdID, out tmp_pos_x, out tmp_pos_y, out tmp_pos_z);
                        if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                        {
                            if ((tmp_pos_x < (pos_x - 0.01)) || (tmp_pos_x > (pos_x + 0.01)) || (tmp_pos_y < (pos_y - 0.01)) || (tmp_pos_y > (pos_y + 0.01)) || (tmp_pos_z < (pos_z - 0.01)) || (tmp_pos_z > (pos_z + 0.01)))
                            {
                                Console.WriteLine(" **** Error: TCP position (start) is different.");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Error: motion_command_robot_tcp_position_start_get() ({0})", clinkCs.system_api_result_description_get(caRetVal));
                        }

                        // 로봇을 이동하는 위치 및 방법을 설정
                        // Endeffector단에서의 종료 위치 설정
                        caRetVal = clinkCs.motion_command_robot_tcp_position_end_set(curMtCmdID, RECT_POINT[rectPtIndex, 0], RECT_POINT[rectPtIndex, 1], RECT_POINT[rectPtIndex, 2]);
                        if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                        {
                            Console.WriteLine("Error: motion_command_robot_tcp_position_end_set() ({0})", clinkCs.system_api_result_description_get(caRetVal));
                        }

                        caRetVal = clinkCs.motion_command_robot_tcp_position_end_get(curMtCmdID, out tmp_pos_x, out tmp_pos_y, out tmp_pos_z);
                        if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                        {
                            if ((tmp_pos_x < (RECT_POINT[rectPtIndex, 0] - 0.01)) || (tmp_pos_x > (RECT_POINT[rectPtIndex, 0] + 0.01)) || (tmp_pos_y < (RECT_POINT[rectPtIndex, 1] - 0.01)) || (tmp_pos_y > (RECT_POINT[rectPtIndex, 1] + 0.01)) || (tmp_pos_z < (RECT_POINT[rectPtIndex, 2] - 0.01)) || (tmp_pos_z > (RECT_POINT[rectPtIndex, 2] + 0.01)))
                            {
                                Console.WriteLine(" **** Error: TCP position (end) is different.");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Error: motion_command_robot_tcp_position_end_get() ({0})", clinkCs.system_api_result_description_get(caRetVal));
                        }

                        // motion command queue에 명령 추가
                        caRetVal = clinkCs.motion_command_queue_add(curMtCmdID);
                        if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                        {
                            Console.WriteLine("---- info: add a motion command (ID={0}) to queue.", curMtCmdID);
                        }
                        else
                        {
                            Console.WriteLine("Error: motion_command_queue_add() ({0})", clinkCs.system_api_result_description_get(caRetVal));
                        }

                        // 로봇 이동 명령
                        caRetVal = clinkCs.motion_command_queue_flush();
                        if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                        {
                            Console.WriteLine("Error: motion_command_queue_flush() ({0})", clinkCs.system_api_result_description_get(caRetVal));
                        }

                        Thread.Sleep(10);
                        if ((NUM_OF_ITERATION - 1) == iterIndex)
                        {
                            Console.WriteLine("+++++++++ robot stop +++++++++");
                            // Stop time을 지정하는 경우
                            caRetVal = clinkCs.robot_stop(robotID, 0.5F);
                            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                            {
                                Console.WriteLine("Error: robot_stop() ({0})", clinkCs.system_api_result_description_get(caRetVal));
                            }

                            caRetVal = clinkCs.motion_command_destroy(curMtCmdID);
                            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                            {
                                Console.WriteLine("Error: motion_command_destroy() ({0})", clinkCs.system_api_result_description_get(caRetVal));
                            }

                            break;
                        }
                        else
                        {
                            // 로봇 이동이 완료될 때까지 기다린다.
                            caRetVal = clinkCs.system_wait_event_group_subgroup_sender_id((uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_MOTION_COMMAND, (uint)CLINK_EVENT_SUBGRP_MOTION_COMMAND.CLINK_EVENT_SUBGRP_MOTION_COMMAND_SETTLED_DOWN, curMtCmdID, 6000, (char)1, out eventResult);
                            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                            {
                                if (eventResult != 1)
                                {
                                    Console.WriteLine(" ---- info: event not occurred (motion command id: {0})", curMtCmdID);
                                }
                            }
                            else
                            {
                                Console.WriteLine("Error: system_wait_event_group_subgroup_sender_id() ({0})", clinkCs.system_api_result_description_get(caRetVal));
                            }

                            caRetVal = clinkCs.robot_tcp_pose_command_get(robotID, out pos_x, out pos_y, out pos_z, out ort_x, out ort_y, out ort_z);
                            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                            {
                                //Console.WriteLine(" ---- info: (command) Position=({0}, {1}, {2}), Orientation=({3}, {4}, {5})", pos_x, pos_y, pos_z, ort_x, ort_y, ort_z);
                            }
                            else
                            {
                                Console.WriteLine("Error: robot_tcp_pose_command_get() ({0})", clinkCs.system_api_result_description_get(caRetVal));
                            }
                        }
                    }
                }
            }

            Thread.Sleep(1000);


            //---------------------------------------------------------------------
            // servo off
            //---------------------------------------------------------------------
            //clinkCs.robot_servo_switch_set은 actuator의 servo를 On/Off하는 함수
            //CLINK_SWITCH_ON: servo on
            //CLINK_SWITCH_OFF: servo off
            Console.WriteLine("+++++++++ servo off +++++++++");
            caRetVal = clinkCs.robot_servo_switch_set(robotID, CLINK_SWITCH.CLINK_SWITCH_OFF);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_servo_switch_set(OFF) ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            // servo 상태
            int switchState;
            caRetVal = clinkCs.robot_servo_switch_get(robotID, out switchState);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if (switchState != (int)CLINK_SWITCH.CLINK_SWITCH_OFF)
                {
                    Console.WriteLine(" **** Error: servo state is not [OFF].");
                }
            }
            else
            {
                Console.WriteLine("Error: robot_servo_switch_get() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            return (int)caRetVal;
        }
    }
}

