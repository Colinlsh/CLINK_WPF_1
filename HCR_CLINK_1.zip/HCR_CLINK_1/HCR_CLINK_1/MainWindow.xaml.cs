﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using System.Runtime.InteropServices;
using clinkv2api_test_cs;

namespace HCR_CLINK_1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //String HOST_IPADDR = "192.168.100.200";
        //String TARGET_IPADDR = "192.168.100.240";
        //uint BOARD_PORT_NUMBER = 5000;
        ////String HCR5_CONFIG_FILE_NAME = "E:/development/svn_branch01/clink_api_welding/config/sample_config.txt";
        //String HCR5_CONFIG_FILE_NAME = "C:/MVS_projects/HCR_CLINK_1/HCR_CLINK_1/config/sample_config.txt";
        //CLINK_ROBOT_MODEL INT_TEST_CUR_ROBOT_ID = CLINK_ROBOT_MODEL.CLINK_ROBOT_MODEL_HCR5;

        // library instance
        clinkv2api_TestMain ctm;

        public const int NUM_OF_ROBOT_JOINTS = 6;

        public uint ctrlBoxID;
        public uint robotID;

        Thread setupRobot;
        enum COORDINATESYS
        {
            TCP,
            BASE
        }

        public MainWindow()
        {
            InitializeComponent();
            ctm = new clinkv2api_TestMain();
            setupRobot = new Thread(new ThreadStart(ctm.SetUp));
        }

        private void Grid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void connectButton_click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (setupRobot.ThreadState != ThreadState.Running)
                {
                    setupRobot.Start();
                }

            }
            catch (Exception er)
            {

                Console.WriteLine(er.ToString());
            }
            

        }

        private void setMove(COORDINATESYS coor,int dist)
        {
            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            //---------------------------------------------------------------------
            // servo on
            //---------------------------------------------------------------------
            Console.WriteLine("+++++++++ servo on +++++++++");

            // clinkCs.robot_servo_switch_set은 actuator의 servo를 On/Off하는 함수
            // CLINK_SWITCH_ON : servo on
            // CLINK_SWITCH_OFF : servo off
            caRetVal = clinkCs.robot_servo_switch_set(robotID, CLINK_SWITCH.CLINK_SWITCH_ON);
            Thread.Sleep(200);

            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_servo_switch_set(ON) ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }
        }

        private void homeButton_Click(object sender, RoutedEventArgs e)
        {
            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            //---------------------------------------------------------------------
            // servo on
            //---------------------------------------------------------------------
            Console.WriteLine("+++++++++ servo on +++++++++");

            // clinkCs.robot_servo_switch_set은 actuator의 servo를 On/Off하는 함수
            // CLINK_SWITCH_ON : servo on
            // CLINK_SWITCH_OFF : servo off
            caRetVal = clinkCs.robot_servo_switch_set(robotID, CLINK_SWITCH.CLINK_SWITCH_ON);
            Thread.Sleep(200);

            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_servo_switch_set(ON) ({0}) {1}", caRetVal, clinkCs.system_api_result_description_get(caRetVal));
            }

            //---------------------------------------------------------------------
            //  각 축 homing
            //---------------------------------------------------------------------
            Console.WriteLine("+++++++++ robot homing +++++++++");

            // 로봇을 설정된 초기 위치로 복귀
            caRetVal = ctm.move_homing(robotID);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: move_homing() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }
        }

        private void directTeachButton_Click(object sender, RoutedEventArgs e)
        {
            //---------------------------------------------------------------------
            //  DIRECT TEACHING MODE
            //---------------------------------------------------------------------
            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;
            Console.WriteLine(" -- [d] pushed, direct teaching mode");
            caRetVal = clinkCs.robot_direct_teaching_switch_set(robotID, CLINK_SWITCH.CLINK_SWITCH_ON);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: clink_robot_direct_teaching_switch_set(ON) ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            //Console.WriteLine("      |--> please enter 'k' to end the direct teaching");
            //while (true)
            //{
            //    string newPushedKey = Console.ReadLine();
            //    if (newPushedKey == "k")
            //    {
            //        caRetVal = clinkCs.robot_direct_teaching_switch_set(robotID, CLINK_SWITCH.CLINK_SWITCH_OFF);
            //        if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //        {
            //            break;
            //        }
            //        else
            //        {
            //            Console.WriteLine("Error: clink_robot_direct_teaching_switch_set(OFF) ({0})", clinkCs.system_api_result_description_get(caRetVal));
            //        }
            //    }
            //}
        }
    }
}
