﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace clinkv2api_test_cs
{
    public partial class clinkv2api_TestMain
    {
        String HOST_IPADDR = "192.168.100.200";
        String TARGET_IPADDR = "192.168.100.240";
        uint BOARD_PORT_NUMBER = 5000;
        //String HCR5_CONFIG_FILE_NAME = "E:/development/svn_branch01/clink_api_welding/config/sample_config.txt";
        //String HCR5_CONFIG_FILE_NAME = "C:/HCR_API/API/KOREAN/Polishing/clink_api_deployment_181109/config/sample_config.txt";
        String HCR5_CONFIG_FILE_NAME = "C:/MVS_projects/HCR_CLINK_1/HCR_CLINK_1/config/sample_config.txt";
        CLINK_ROBOT_MODEL INT_TEST_CUR_ROBOT_ID = CLINK_ROBOT_MODEL.CLINK_ROBOT_MODEL_HCR5;

        public const int NUM_OF_ROBOT_JOINTS = 6;

        public uint ctrlBoxID;
        public uint robotID;

        public CLINK_API_RESULT move_homing(uint rbHandleID)
        {
            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;
            int eventResult;
#if __OLD_STYLE_OF_OLD_INTERNAL_DESIGN_FOR_JOINT_MOTION_COMMAND__
            uint[] mtCmdAry = new uint[7];
#endif // __OLD_STYLE_OF_OLD_INTERNAL_DESIGN_FOR_JOINT_MOTION_COMMAND__

            // create a motion command data (Joint)
            uint curMtCmdID = 0;
            caRetVal = clinkCs.motion_command_robot_joint_create(out curMtCmdID);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: motion_command_robot_joint_create() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            caRetVal = clinkCs.motion_command_robot_robot_id_set(curMtCmdID, rbHandleID);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: motion_command_robot_robot_id_set() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            // Home Position에 이동하기 위한 parameters
            float maxAcc = 300.0F;
            float maxDec = 300.0F;
            float maxVel = 50.0F;

            // Home Position에 대한 Joint각도
            var homeAngle = new float[6]{ 0.0F, -90.0F, -90.0F, -90.0F, 90.0F, 0.0F };

            caRetVal = clinkCs.motion_command_speed_max_set(curMtCmdID, maxVel);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: motion_command_speed_max_set() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            caRetVal = clinkCs.motion_command_acc_max_set(curMtCmdID, maxAcc);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: motion_command_acc_max_set() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            caRetVal = clinkCs.motion_command_dec_max_set(curMtCmdID, maxDec);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: motion_command_dec_max_set() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            caRetVal = clinkCs.motion_command_jerk_percentage_set(curMtCmdID, 1.0F);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: motion_command_jerk_percentage_set() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            for (uint i = 0; i < 6; i++)
            {
                // Joint 각도 설정
                caRetVal = clinkCs.motion_command_robot_joint_angle_end_set(curMtCmdID, i, homeAngle[i]);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    Console.WriteLine("Error: motion_command_robot_joint_angle_end_set() ({0})", clinkCs.system_api_result_description_get(caRetVal));
                }
            }

            // motion command queue에 명령 추가
            caRetVal = clinkCs.motion_command_queue_add(curMtCmdID);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("---- info: add motion command (ID={0}) to queue.", curMtCmdID);
            }
            else
            {
                Console.WriteLine("Error: motion_command_queue_add() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            // 로봇 이동 명령
            caRetVal = clinkCs.motion_command_queue_flush();
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: motion_command_queue_flush() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            Thread.Sleep(50);

            // 로봇 이동이 완료될 때까지 기다린다.
            caRetVal = clinkCs.system_wait_event_group_subgroup_sender_id((uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_MOTION_COMMAND, (uint)CLINK_EVENT_SUBGRP_MOTION_COMMAND.CLINK_EVENT_SUBGRP_MOTION_COMMAND_SETTLED_DOWN, curMtCmdID, 5000, (char)1, out eventResult);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if (eventResult != 1)
                {
                    Console.WriteLine(" ---- info: event not occurred (motion command id: {0})", curMtCmdID);
                }
            }
            else
            {
                Console.WriteLine("Error: system_wait_event_group_subgroup_sender_id() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            // destroy a created motion command
            caRetVal = clinkCs.motion_command_destroy(curMtCmdID);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: motion_command_destroy() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            return caRetVal;
        }

        public void SetUp()
        {
            Console.WriteLine("--SetUp()----");

            // initialize library
            CLINK_API_RESULT caRetVal = clinkCs.system_create(HCR5_CONFIG_FILE_NAME);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) {
                Console.WriteLine("Error: system_create() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            // create a control box instance
            caRetVal = clinkCs.control_box_create(CLINK_CBOX_MODEL.CLINK_CBOX_MODEL_HCR5_001, HCR5_CONFIG_FILE_NAME, out ctrlBoxID);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: control_box_create() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            int cbModel;
            caRetVal = clinkCs.control_box_name_get(ctrlBoxID, out cbModel);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if (cbModel != (int) CLINK_CBOX_MODEL.CLINK_CBOX_MODEL_HCR5_001)
                {
                    Console.WriteLine("Error: control_box_name_get() returned a invalid control box model name: {0}", cbModel);
                }
            }
            else
            {
                Console.WriteLine("Error: control_box_name_get() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            // connect to a control box
            caRetVal = clinkCs.control_box_connect_by_socket(ctrlBoxID, HOST_IPADDR, TARGET_IPADDR, BOARD_PORT_NUMBER);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: control_box_connect_by_socket() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            Console.WriteLine("CREATING ROBOT INSTANCE...");
            // create a robot instance
            caRetVal = clinkCs.robot_create(ctrlBoxID, INT_TEST_CUR_ROBOT_ID, null, 0, out robotID);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_create() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }
            Console.WriteLine("GETTING ROBOT MODEL NAME...");
            int rbModel;
            caRetVal = clinkCs.robot_model_name_get(robotID, out rbModel);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if (rbModel != (int)INT_TEST_CUR_ROBOT_ID)
                {
                    Console.WriteLine("Error: control_box_name_get() returned a invalid robot model name: {0}", rbModel);
                }
            }
            else
            {
                Console.WriteLine("Error: robot_model_name_get() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            // current operational mode of robot
            int opMode;
            caRetVal = clinkCs.robot_operational_mode_get(robotID, out opMode);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.Write("---- info: current operationa mode is \"");
                switch (opMode)
                {
                    case (int) CLINK_OPERATIONAL_MODE.CLINK_OPERATIONAL_MODE_INIT:
                        Console.Write("INIT");
                        break;
                    case (int)CLINK_OPERATIONAL_MODE.CLINK_OPERATIONAL_MODE_PRE_OPERATIONAL:
                        Console.Write("PRE_OPERATIONAL");
                        break;
                    case (int)CLINK_OPERATIONAL_MODE.CLINK_OPERATIONAL_MODE_BOOTSTRAP:
                        Console.Write("BOOTSTRAP");
                        break;
                    case (int)CLINK_OPERATIONAL_MODE.CLINK_OPERATIONAL_MODE_SAFE_OPERATIONAL:
                        Console.Write("SAFE_OPERATIONAL");
                        break;
                    case (int)CLINK_OPERATIONAL_MODE.CLINK_OPERATIONAL_MODE_OPERATIONAL:
                        Console.Write("OPERATIONAL");
                        break;
                    default:
                        Console.Write("unknown");
                        break;
                }
                Console.WriteLine("\".");
            }
            else
            {
                Console.WriteLine("Error: robot_operational_mode_get() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

        }

        public void TearDown()
        {
            CLINK_API_RESULT caRetVal = clinkCs.robot_destroy(robotID);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_destroy() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            caRetVal = clinkCs.control_box_destroy(ctrlBoxID);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: control_box_destroy() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            caRetVal = clinkCs.system_destroy();
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: system_destroy() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            Console.WriteLine("--TearDown()----");
        }

        //static void Main(string[] args)
        //{
        //    clinkv2api_TestMain ctm = new clinkv2api_TestMain();

        //    ctm.SetUp();

        //    ctm.runTest();

        //    ctm.TearDown();

        //    ctm = null;
        //}
    }
}
